package com.example.android_kotlin_examen

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ListView
import androidx.recyclerview.widget.RecyclerView

class CompanyAdapter(private val context:Context , private val companyDAO: CompanyDAO): RecyclerView.Adapter<CompanyViewHolder>() {
    override fun getItemCount(): Int {
        return companyDAO.count()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CompanyViewHolder {
        return CompanyViewHolder(
                LayoutInflater.from(context)
                        .inflate(R.layout.activity_main, parent, false) as ListView
        )
    }

    override fun onBindViewHolder(holder: CompanyViewHolder, position: Int) {
        val comp = companyDAO.getByPosition(position) ?: return
        holder.textNameCompany.text = comp.toString()
    }

}