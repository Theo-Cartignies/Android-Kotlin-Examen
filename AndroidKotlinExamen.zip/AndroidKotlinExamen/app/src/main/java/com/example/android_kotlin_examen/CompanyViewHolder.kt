package com.example.android_kotlin_examen

import android.widget.ListView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CompanyViewHolder(row : ListView): RecyclerView.ViewHolder(row) {
    val textNameCompany = row.findViewById<TextView>(R.id.textview_CompanyName)
}