package com.example.android_kotlin_examen

import android.content.Intent
import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.JsonReader
import android.view.View
import android.widget.*

class MainActivity : AppCompatActivity() {

    inner class QueryTask(private val svc:searchCompanyService,
                          private val listResult: ListView,
                          private val progressBar: ProgressBar):
            AsyncTask<String, Void, List<Company>>() {

        override fun onPreExecute() {
            progressBar.visibility = View.VISIBLE
            listResult.visibility = View.INVISIBLE
        }

        override fun doInBackground(vararg params: String?): List<Company>? {
            val query = params[0] ?: return emptyList()
            return svc.getComp(query)

        }

        override fun onPostExecute(result: List<Company>?) {
            listResult.adapter = ArrayAdapter<Company>(applicationContext,
                    android.R.layout.simple_list_item_1,
                    android.R.id.text1,
                    result!!)
            progressBar.visibility = View.INVISIBLE
            listResult.visibility = View.VISIBLE
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val dbcomp = CompanyDatabase.getDatabase(this)
        val daocomp = dbcomp.dao()

        val listtesults = findViewById<ListView>(R.id.listResults)
        val Process = findViewById<ProgressBar>(R.id.progressbar_Search)
        val svc = searchCompanyService(daocomp)



        findViewById<ImageButton>(R.id.imageButton_Search).setOnClickListener {
            val query = findViewById<EditText>(R.id.edit_query).text.toString()
            QueryTask(svc = svc, listResult = listtesults, progressBar = Process).execute(query)
        }

        findViewById<ListView>(R.id.listResults).setOnItemClickListener(){ _, _, position,_->
            val comp = findViewById<ListView>(R.id.listResults).adapter.getItem(position) as Company
            val intent = Intent(applicationContext, companyDetails::class.java)
            intent.putExtra("Company", comp)
            startActivity(intent)
        }
    }
}


