package com.example.android_kotlin_examen

import androidx.room.*

@Dao
interface CompanyDAO {
    @Query("SELECT * FROM Company ORDER BY nameCompany")
    fun getAll() : List<Company>

    @Query("SELECT *FROM Company WHERE id=:param ")
    fun getById(param:Long): Company?

    @Query("SELECT COUNT(*) FROM Company")
    fun count() : Int

    @Query("SELECT * FROM Company ORDER BY nameCompany LIMIT 1 OFFSET :position ")
    fun getByPosition(position: Int): Company?

    @Insert
    fun insert(company: Company):Long

    @Update
    fun update(company: Company)

    @Delete
    fun delete(company: Company)

}