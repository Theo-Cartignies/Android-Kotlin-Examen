package com.example.android_kotlin_examen

import android.util.JsonReader
import android.util.JsonToken
import org.w3c.dom.Entity
import java.io.IOException
import java.net.URL
import javax.net.ssl.HttpsURLConnection

class searchCompanyService(private val dao: CompanyDAO) {
    private val apiUrl = "https://entreprise.data.gouv.fr/"
    private val apiQuerry = "$apiUrl/api/sirene/v1/full_text/%s?page=1&per_page=100"

    fun getComp(query: String): List<Company> {
        val url = URL(String.format(apiQuerry, query))
        var conn : HttpsURLConnection? = null
        try {
            conn = url.openConnection() as HttpsURLConnection
            conn.connect()
            if (conn.responseCode != HttpsURLConnection.HTTP_OK) {
                return emptyList()
            }
            val inputStream = conn.inputStream ?: return emptyList()
            val reader = JsonReader(inputStream.bufferedReader())
            val result = mutableListOf<Company>()
            reader.beginObject()
            while (reader.hasNext()) {
                if (reader.nextName() == "etablissement") {
                    reader.beginArray()
                    while (reader.hasNext()) {
                        reader.beginObject()
                        val Comp = Company(nameCompany = "", departement = "", id = 0,nameBoss = "",fullNameBoss = "",mainActivity = "",address = "")
                            while (reader.hasNext()) {
                                when (reader.nextName()) {
                                    "id" -> Comp.id = reader.nextLong()
                                    "nom_raison_sociale" -> Comp.nameCompany = reader.nextString()
                                    "departement" -> {
                                        if (reader.peek() != JsonToken.NULL) {
                                            Comp.departement = reader.nextString()
                                        } else {
                                            Comp.address = ""
                                            reader.skipValue()
                                        }
                                    }
                                    "libelle_activite_principale_entreprise" -> Comp.mainActivity = reader.nextString()
                                    "geo_adresse" -> {
                                        if (reader.peek() != JsonToken.NULL) {
                                            Comp.address = reader.nextString()
                                        } else {
                                            Comp.address = ""
                                            reader.skipValue()
                                        }
                                    }
                                    "nom" ->if (reader.peek() != JsonToken.NULL) {
                                        Comp.nameBoss = reader.nextString()
                                    } else {
                                        Comp.nameBoss = ""
                                        reader.skipValue()
                                    }
                                    "prenom" ->if (reader.peek() != JsonToken.NULL) {
                                        Comp.fullNameBoss = reader.nextString()
                                    } else {
                                        Comp.fullNameBoss = ""
                                        reader.skipValue()
                                    }
                                else -> reader.skipValue()
                                }
                            }
                            reader.endObject()
                        result.add(Comp)
                        if (dao.getById(Comp.id) == null){
                            dao.insert(Comp)
                        }
                    }
                    reader.endArray()
                } else {
                    reader.skipValue()
                }
            }
            reader.endObject()
            return result

        } catch (e: IOException) {
            return emptyList()
        } finally {
            conn?.disconnect()
        }
    }

}
