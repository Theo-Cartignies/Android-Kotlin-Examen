package com.example.android_kotlin_examen

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import java.io.Serializable



@Entity
data class Company(@PrimaryKey var id : Long,
                   var nameCompany:String,
                   var departement:String,
                   var nameBoss:String,
                   var fullNameBoss:String,
                   var mainActivity:String,
                   var address:String,
                   ):Serializable
{
    override fun toString(): String {
        return "$nameCompany $departement"
    }
}