package com.example.android_kotlin_examen

import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView

class companyDetails : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_company_details)
        val Compa = intent?.extras?.get("Company") as? Company ?: return

        findViewById<TextView>(R.id.textview_CompanyName).text = String.format(resources.getString(R.string.companyName),Compa.nameCompany)

        if (Compa.nameBoss.length == 0 && Compa.fullNameBoss.length == 0 ){
            findViewById<TextView>(R.id.textview_BossName).text = String.format(resources.getString(R.string.errorNameboss))
        }else {
            findViewById<TextView>(R.id.textview_BossName).text = String.format(resources.getString(R.string.bossName),Compa.nameBoss,Compa.fullNameBoss)
        }


        if (Compa.address.length == 0){
            findViewById<TextView>(R.id.textview_Addresse).text = String.format(resources.getString(R.string.errorAdresse))
        }else{
            findViewById<TextView>(R.id.textview_Addresse).text = String.format(resources.getString(R.string.adrresse),Compa.address)
        }

        findViewById<TextView>(R.id.textview_Activity).text = String.format(resources.getString(R.string.activity),Compa.mainActivity)

    }
}